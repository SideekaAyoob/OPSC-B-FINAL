package com.Ayoob.avian

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TaskStackBuilder
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import java.text.DateFormat
import java.util.Calendar

class create_My_Observation : AppCompatActivity() {

//variables
   private lateinit var saveButton: Button
    private lateinit var dataName: TextView
    private lateinit var dataLocation: TextView
    private lateinit var dataDate: TextView
    private lateinit var dataDesc: TextView
    private lateinit var mAuth: FirebaseAuth
    private lateinit var uploadImage:ImageView

    var imageURL: String? = null
    var uri: Uri? = null

    //variables for notification
    private val CHANNEL_ID = "channelId"
    private val CHANNEL_NAME = "channelName"
    private val NOTIFICATION_ID = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_my_observation)

        //type casting
        dataName = findViewById(R.id.birdName)
        dataLocation = findViewById(R.id.observationLocation)
        dataDate = findViewById(R.id.observationDate)
        dataDesc = findViewById(R.id.observationDesc)
       uploadImage = findViewById(R.id.uploadImage)

        mAuth=FirebaseAuth.getInstance()
        notificationChannel()
        saveButton= findViewById(R.id.saveButton)

        val activityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
            ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val data = result.data
                uri = data!!.data
                uploadImage.setImageURI(uri)
            } else {
                Toast.makeText(this@create_My_Observation, "No Image Selected",
                    Toast.LENGTH_SHORT).show()
            }
        }

        uploadImage.setOnClickListener{
            val photoPicker =Intent(Intent.ACTION_PICK )
            photoPicker.type ="image/*"
            activityResultLauncher.launch(photoPicker)
             Toast.makeText(this@create_My_Observation, "You have taken a picture already", Toast.LENGTH_SHORT).show()
        }//end upload image


        val currentDate = DateFormat.getDateInstance().format(Calendar.getInstance().time)
        dataDate.text=currentDate.toString()

        saveButton.setOnClickListener {
          // uploadData()
            saveData()
        }// end save button onclick
    }// end on create

    private fun saveData()
    {
        val storageReference = FirebaseStorage.getInstance().reference.child("Task Images")
            .child(uri!!.lastPathSegment!!)

        storageReference.putFile(uri!!).addOnSuccessListener { taskSnapshot ->
            val uriTask = taskSnapshot.storage.downloadUrl
            while (!uriTask.isComplete);
            val urlImage = uriTask.result
            imageURL = urlImage.toString()
            Toast.makeText(this@create_My_Observation, "worked", Toast.LENGTH_SHORT).show()
            // dialog.dismiss()
            uploadData()
        }.addOnFailureListener {
            // dialog.dismiss()
            Toast.makeText(this@create_My_Observation, "doesnt work", Toast.LENGTH_SHORT).show()
        }
    }


    @SuppressLint("MissingPermission")
    private fun uploadData(){
//=========================================================================================
// for notifications
        //val intent = Intent(this, NewNotification::class.java)
        val pendingIntent = TaskStackBuilder.create(this).run {
            addNextIntentWithParentStack(intent)
            getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT)

        }// end pending intent

        val success = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("✴ Observation Creation successful")
            .setContentText("You have successfully created an observation")
            .setSmallIcon(R.drawable.avianlogo)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .build()

        val unSuccessful = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("✴ Observation Creation Un-successful")
            .setContentText("You have not successfully created an observation")
            .setSmallIcon(R.drawable.avianlogo)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .build()
//=========================================================================================


        val builder = AlertDialog.Builder(this@create_My_Observation)
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()

        /////////////////////////////////////////////////////////////////////////////////

      /////////////////////////////////////////////////////////////////////////////////////////

        val title = dataName.text.toString()
        val desc =dataDesc.text.toString()
        val location =dataLocation.text.toString()
        val obDate =dataDate.text.toString()

        val userid = mAuth.currentUser!!.uid
        val Route ="$userid/MyObservations" //

        val dataClass =myObservationsDataClass (title, desc,obDate,location,imageURL)//

        val currentDate = DateFormat.getDateTimeInstance().format(Calendar.getInstance().time)

        FirebaseDatabase.getInstance().getReference(Route).child(currentDate)
            .setValue(dataClass).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val  notificationManagerCompat = NotificationManagerCompat.from(this)
                    notificationManagerCompat.notify(NOTIFICATION_ID, success)
                    Toast.makeText(this@create_My_Observation, "Saved", Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                    finish()
                }
                else
                {
                    val  notificationManagerCompat = NotificationManagerCompat.from(this)
                    notificationManagerCompat.notify(NOTIFICATION_ID, unSuccessful)
                    Toast.makeText(this@create_My_Observation, "Not Saved", Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                    finish()

                }
            }.addOnFailureListener { e ->
                Toast.makeText(
                    this@create_My_Observation, e.message.toString(), Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
    }// end upload

    private fun notificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                lightColor = Color.BLUE
                enableLights(true)

            }
            val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)

        }// end if
    }

}//end main