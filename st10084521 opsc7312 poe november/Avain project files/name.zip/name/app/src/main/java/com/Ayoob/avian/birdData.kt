package com.Ayoob.avian

class birdData : ArrayList<birdDataItem>()