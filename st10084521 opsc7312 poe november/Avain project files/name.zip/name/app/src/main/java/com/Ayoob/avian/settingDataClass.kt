package com.Ayoob.avian

class settingDataClass {
        var measurment:String?= null
        var settingname:String? = null

        constructor(measurment:String?,settingName:String? ){
            this.measurment=measurment
            this.settingname = settingName
        }
        constructor()

}// end class