package com.Ayoob.avian

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TaskStackBuilder
import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class Register : AppCompatActivity() {
    //variables
    private lateinit var tvTitle: TextView
    private lateinit var edUserName: EditText
    private lateinit var edPassword: EditText
    private lateinit var edConfirmPassword: EditText
    private lateinit var btnRegister: Button
    private lateinit var btnCancelReg: Button
    private lateinit var mAuth: FirebaseAuth

    //variables for notification
    private val CHANNEL_ID = "channelId"
    private val CHANNEL_NAME = "channelName"
    private val NOTIFICATION_ID = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        //////////typecast
        tvTitle = findViewById(R.id.textView2)
        edUserName = findViewById(R.id.editTextTextEmailAddress2)
        edPassword = findViewById(R.id.editTextTextPassword2)
        edConfirmPassword = findViewById(R.id.editTextTextPassword3)
        btnRegister = findViewById(R.id.button3)
        btnCancelReg = findViewById(R.id.button4)

        notificationChannel()
        mAuth = FirebaseAuth.getInstance()

    }//end on create

    @SuppressLint("MissingPermission")
    fun regUser(view: View) {
//=========================================================================================
// for notifications
        //val intent = Intent(this, NewNotification::class.java)
        val pendingIntent = TaskStackBuilder.create(this).run {
            addNextIntentWithParentStack(intent)
            getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT)

        }// end pending intent

        val success = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("✴ Registered in successfully")
            .setContentText("You have Registered in successfully")
            .setSmallIcon(R.drawable.avianlogo)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .build()

        val unSuccessful = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("✴ Registered in Un-successfully")
            .setContentText("You  have not Registered in un-successfully")
            .setSmallIcon(R.drawable.avianlogo)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .build()
//=========================================================================================


        if (view.id == R.id.button3) {
            val email = edUserName.text.toString().trim()
            val passwordReg = edPassword.text.toString().trim()
            val conPassword = edConfirmPassword.text.toString().trim()

            if (TextUtils.isEmpty(email)) {
                Toast.makeText(this, "Email can't be blank", Toast.LENGTH_SHORT).show()
                return
            }
            if (TextUtils.isEmpty(passwordReg)) {
                Toast.makeText(this, "Password can't be blank", Toast.LENGTH_SHORT).show()
                return
            }
            if (TextUtils.isEmpty(conPassword)) {
                Toast.makeText(this, "Confirm password can't be blank", Toast.LENGTH_SHORT).show()
                return
            }

            if (conPassword == passwordReg) {
                mAuth.createUserWithEmailAndPassword(email,passwordReg).addOnCompleteListener(this,
                    OnCompleteListener<AuthResult> {task ->
                        if (task.isSuccessful) {
                            val  notificationManagerCompat = NotificationManagerCompat.from(this)
                            notificationManagerCompat.notify(NOTIFICATION_ID, success)
                            val intent = Intent(this@Register, Login::class.java)
                            startActivity(intent)
                            mAuth = FirebaseAuth.getInstance()
                            val uid = mAuth.uid.toString()
                            if (uid != null) {
                                createUserPointsProfiles(uid)
                            } else {
                                val  notificationManagerCompat = NotificationManagerCompat.from(this)
                                notificationManagerCompat.notify(NOTIFICATION_ID, unSuccessful)
                                Toast.makeText(this@Register,"Register not successful",
                                    Toast.LENGTH_SHORT
                                )
                                    .show()
                            }// end if mauth = null
                            finish()
                        } else {
                            Toast.makeText(this@Register, "FAILED TO REG", Toast.LENGTH_SHORT).show()
                        }
                    })

            }
        else
            {
                Toast.makeText(this@Register, "Passwords don't match", Toast.LENGTH_SHORT).show()

            }// end if password == confirm
        }//end if
    }// end reg

    private fun createUserPointsProfiles( uid :String?) {
        // diary
        val uidpoints = "$uid/Points"
        val diaryDataClass = PointsDataClass(0, "MyObservationPoints")//
        FirebaseDatabase.getInstance().getReference(uidpoints).child("MyObservationPoints")
            .setValue(diaryDataClass).addOnCompleteListener { task ->
                if (task.isSuccessful) {

                }
            }.addOnFailureListener { e ->

            }// end firebase else


    }// end
    private fun notificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                lightColor = Color.BLUE
                enableLights(true)

            }
            val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)

        }// end if
    }

}// end class




