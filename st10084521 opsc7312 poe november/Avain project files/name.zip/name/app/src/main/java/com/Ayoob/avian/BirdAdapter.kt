package com.Ayoob.avian

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
//import com.example.name.R

class BirdAdapter  (private val birdDataList: List<birdDataItem>) :
RecyclerView.Adapter<BirdAdapter.Viewholder>(){

    class Viewholder(itemView:View): RecyclerView.ViewHolder(itemView) {
        val speciesCodeTextView: TextView = itemView.findViewById(R.id.speciesCodeTV)
        val commonNameTextView: TextView = itemView.findViewById(R.id.commonNameTV)
        val scientificNameTextView: TextView = itemView.findViewById(R.id.scientific_nameTV)
        val predictionYearTextView: TextView = itemView.findViewById(R.id.prediction_yearTV)
        val regionTypeTextView: TextView = itemView.findViewById(R.id.regiontypeTV)

        val regionCodeTextView: TextView = itemView.findViewById(R.id.regioncodeTV)
        val regionNameTextView: TextView = itemView.findViewById(R.id.regionnameTV)

        val seasonTextView: TextView = itemView.findViewById(R.id.seasonTV)
        val startDateTextView: TextView = itemView.findViewById(R.id.startdateTV)
        val endDateTextView: TextView = itemView.findViewById(R.id.enddateTV)
        val abundanceMeanTextView: TextView = itemView.findViewById(R.id.abundance_meanTV)
        val totalPopPercentTextView: TextView = itemView.findViewById(R.id.total_pop_percentTV)
        val rangePercentOccupiedTextView: TextView = itemView.findViewById(R.id.range_percent_occupiedTV)
        val rangeTotalPercentTextView: TextView = itemView.findViewById(R.id.range_total_percentTV)
        val rangeDaysOccupationTextView: TextView = itemView.findViewById(R.id.range_days_occupationTV)

    }
    override fun onCreateViewHolder(parent: ViewGroup,viewType: Int): Viewholder
    {
        val itemView=
            LayoutInflater.from(parent.context).inflate(R.layout.item_bird,parent,false)
        return Viewholder (itemView)
    }

    override fun onBindViewHolder(holder: Viewholder, position: Int) {
        val birdData = birdDataList[position]
        holder.speciesCodeTextView.text="species code:${birdData.species_code}"
        holder.commonNameTextView.text="species code:${birdData.common_name}"
        holder.speciesCodeTextView.text="species code:${birdData.species_code}"
        holder.scientificNameTextView.text="species code:${birdData.scientific_name}"
        holder.predictionYearTextView.text="species code:${birdData.prediction_year}"

        holder.regionCodeTextView.text="species code:${birdData.region_code}"
        holder.regionTypeTextView.text="species code:${birdData.region_type}"
        holder.regionNameTextView.text="species code:${birdData.region_name}"
        holder.seasonTextView.text="species code:${birdData.season}"
        holder.startDateTextView.text="species code:${birdData.start_date}"
        holder.endDateTextView.text="species code:${birdData.end_date}"
        holder.abundanceMeanTextView.text="species code:${birdData.abundance_mean}"
        holder.totalPopPercentTextView.text="species code:${birdData.total_pop_percent}"
        holder.rangePercentOccupiedTextView.text="species code:${birdData.range_percent_occupied}"
        holder.rangeTotalPercentTextView.text="species code:${birdData.range_total_percent}"
        holder.rangeDaysOccupationTextView.text="species code:${birdData.range_days_occupation}"
    }

    override fun getItemCount(): Int {
        return birdDataList.size
    }
}
