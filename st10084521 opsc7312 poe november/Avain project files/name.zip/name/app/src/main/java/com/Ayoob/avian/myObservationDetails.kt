package com.Ayoob.avian

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.findViewTreeViewModelStoreOwner
import com.bumptech.glide.Glide


class myObservationDetails : AppCompatActivity() {
    //variables
    private lateinit var saveButton: Button
    private lateinit var dataName: TextView
    private lateinit var dataLocation: TextView
    private lateinit var dataDate: TextView
    private lateinit var dataDesc: TextView
    private lateinit var dataImage: ImageView

    var imageUrl = ""

        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_observation_details)

            //type casting
            dataName = findViewById(R.id.disbirdName)
            dataLocation = findViewById(R.id.disobservationLocation)
            dataDate = findViewById(R.id.disobservationDate)
            dataDesc = findViewById(R.id.disobservationDesc)
            dataImage = findViewById(R.id.detailImage)


            val bundle = intent.extras
            if (bundle != null) {
                dataDesc.text=bundle.getString("Description")
               dataName.text= bundle.getString("Title")
                dataDate.text= bundle.getString("date")
                dataLocation.text= bundle.getString("location")
                imageUrl = bundle.getString("Image")!!
                Glide.with(this).load(bundle.getString("Image"))
                    .into(dataImage)

            }
            dataDesc.movementMethod = ScrollingMovementMethod()


        }//end on create



}// end