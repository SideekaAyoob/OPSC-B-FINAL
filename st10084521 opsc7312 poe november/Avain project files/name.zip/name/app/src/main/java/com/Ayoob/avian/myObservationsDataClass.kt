package com.Ayoob.avian

class myObservationsDataClass {

    var dataBirdName: String? = null
    var dataObservationDesc: String? = null
    var dataObservationDate: String? = null
    var dataObservationLocation: String? = null
    var dataImage: String? = null
    //var dataImage: String? = null dataImage: String?
    constructor(dataBirdName: String?, dataObservationDesc: String?, dataObservationDate: String?,dataObservationLocation: String?, dataImage: String?  ){
        this.dataBirdName = dataBirdName
        this.dataObservationDesc = dataObservationDesc
        this.dataObservationDate = dataObservationDate
        this.dataObservationLocation = dataObservationLocation
        this.dataImage = dataImage
       // this.dataImage = dataImage
    }
    constructor()
}