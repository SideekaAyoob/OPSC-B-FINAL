package com.Ayoob.avian

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.widget.Button
import com.google.android.material.navigation.NavigationView
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.app.AppCompatActivity
import com.Ayoob.avian.databinding.ActivityMainBinding
import android.content.Context
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    // private lateinit var HomeButton: FloatingActionButton
    private lateinit var MapButton:FloatingActionButton
    private lateinit var ProfileButton:FloatingActionButton

    private lateinit var btnbirdpedia:Button
    private lateinit var btnObservations:Button
   // private lateinit var btnAbout:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.appBarMain.toolbar)

        //binding.appBarMain.fab.setOnClickListener { view ->
        //  Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
        //       .setAction("Action", null).show()
        // }
        val drawerLayout: DrawerLayout = binding.drawerLayout
        val navView: NavigationView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow
            ), drawerLayout
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        //navView.setupWithNavController(navController)
        navView.setNavigationItemSelectedListener{item->


//when(id){
            when(item.itemId){
                R.id.nav_map-> {
                   /* val dialog = Dialog(this@MainActivity)
                    dialog.setContentView(R.layout.permission_for_locations)
                    val proceedButton = dialog.findViewById<Button>(R.id.procceedToMap)
                    proceedButton.setOnClickListener{*/
                         val intent = Intent(this@MainActivity, newmap::class.java)
                        startActivity(intent)
                }
                   /* dialog.dismiss()}
                    dialog.show()

                }*/

                R.id.nav_recorder-> {
                    val intent = Intent(this@MainActivity, recorder::class.java)
                    startActivity(intent)
                }
                R.id.nav_observations-> {
                    val intent = Intent(this@MainActivity, observations::class.java)
                    startActivity(intent)
                }
                R.id.nav_birdpedia-> {
                    val intent = Intent(this@MainActivity,birdpedia::class.java)
                    startActivity(intent)
                }
                R.id.nav_Profile-> {
                    val intent = Intent(this@MainActivity,profile::class.java)
                    startActivity(intent)
                }
            }
            true
        }

        //type casting
        //HomeButton=findViewById(R.id.fabHome)
        MapButton=findViewById(R.id.fabMap)
        ProfileButton=findViewById(R.id.fabProfile)

        btnbirdpedia=findViewById(R.id.btnBirpedia)
        btnObservations=findViewById(R.id.btnObservation)
        //btnAbout=findViewById(R.id.btnAbout)

        MapButton.setOnClickListener{

            /*val dialog = Dialog(this@MainActivity)
            dialog.setContentView(R.layout.permission_for_locations)
            val proceedButton = dialog.findViewById<Button>(R.id.procceedToMap)
            proceedButton.setOnClickListener{*/
                val intent = Intent(this@MainActivity, newmap::class.java)
                startActivity(intent)
               /* dialog.dismiss()
               }
                */

        }

        ProfileButton.setOnClickListener{
            val intent = Intent(this@MainActivity, profile::class.java)
            startActivity(intent)
        }

        btnbirdpedia.setOnClickListener{
            val intent = Intent(this@MainActivity, birdpedia::class.java)
            startActivity(intent)
        }

        btnObservations.setOnClickListener{
            val intent = Intent(this@MainActivity, observations::class.java)
            startActivity(intent)
        }

       // btnAbout.setOnClickListener{
            //val intent = Intent(this@MainActivity, birdpedia::class.java)
            // startActivity(intent)
         //   Toast.makeText(this@MainActivity, "This will come in the next version", Toast.LENGTH_SHORT).show()
        //}
    }// end on create

    // Convert a resource ID to a URI
    private fun resourceToUri(context: Context, resId: Int): String {
        return "android.resource://${context.packageName}/$resId"
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }
}