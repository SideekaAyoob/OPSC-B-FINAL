package com.Ayoob.avian

import android.content.pm.PackageManager
import android.media.MediaRecorder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

import java.io.IOException

class recorder : AppCompatActivity() {

        //variables
        private lateinit var mediaRecorder:MediaRecorder
        private var isRecording=false//
        //path to save file
        private var audioFilePath="${Environment.getExternalStorageDirectory().absolutePath}/my_rec.3gp"

        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recorder)

                val btnRec=findViewById<Button>(R.id.button)

                if(checkPermissions())
                {
                        mediaRecorder=MediaRecorder()
                    mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC)
                        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
                        mediaRecorder.setOutputFile(audioFilePath)
                        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)

                        btnRec.setOnClickListener{
                        //same btn-->change the text
                                if(isRecording){
                        //method to stop recording
                                        btnRec.text="Startrecording"
                                }else{
                                        startRecording()
                                        btnRec.text="stoprecording"
                                }//endelse
                        }//end on click
                }
                else
                {
                        requestPermissions()
                }//endif


        }//endoncreate

        private fun checkPermissions():Boolean{
                val writeExternalStoragePermission=ContextCompat.checkSelfPermission(
                        this,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
                val recordAudioPermission=ContextCompat.checkSelfPermission(
                        this,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
                return writeExternalStoragePermission==
                PackageManager.PERMISSION_GRANTED&&
                        recordAudioPermission==PackageManager.PERMISSION_GRANTED
        }// end check permissions


        private fun requestPermissions()
        {
                ActivityCompat.requestPermissions(
                        this,
                        arrayOf(
                                android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                android.Manifest.permission.RECORD_AUDIO
                        ),0

                )//ned activity
        }//end method


        private fun  startRecording()
        {
                try{
                        mediaRecorder.prepare()
                        mediaRecorder.start()
                        isRecording=true
                        Toast.makeText(this,"Recording started",Toast.LENGTH_SHORT).show()

                }catch(e:IOException)
                {
                        e.printStackTrace()
                }//end try
        }//end start

        private fun stopRecording()
        {
                mediaRecorder.stop()
                mediaRecorder.release()
                isRecording=false
                Toast.makeText(this,"recording stopped",Toast.LENGTH_SHORT).show()

        }//end stop

        override fun onRequestPermissionsResult(
        requestCode:Int,
        permissions:Array<out String>,
        grantResults:IntArray
        ){
                super.onRequestPermissionsResult(requestCode,permissions,grantResults)
                if(requestCode==0)
                {
                        if(grantResults.isNotEmpty()&&grantResults[0]==PackageManager.PERMISSION_GRANTED)
                        {
                                recreate()
                        }else{
                                Toast.makeText(this,"Permissiondenied",Toast.LENGTH_SHORT).show()
                        }

                }

        }//end


        override fun onDestroy(){
                super.onDestroy()
                if(isRecording){
                        stopRecording()
                }
        }//enddestroy


}// end class