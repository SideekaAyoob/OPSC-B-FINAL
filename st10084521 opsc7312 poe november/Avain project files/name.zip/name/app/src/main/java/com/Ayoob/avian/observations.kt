package com.Ayoob.avian

import android.content.res.AssetManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.google.gson.Gson
import java.io.IOException

class observations : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_observations)


        val jsonFileName="data.json"
        val json:String?=readJsonFileFromAssets(jsonFileName)

        if(json!=null)
        {
            val birdDataList=Gson().fromJson(json,Array<birdDataItem>::class.java)

            val recyclerView:RecyclerView=findViewById(R.id.recycleView)
            recyclerView.layoutManager=LinearLayoutManager(this)
            recyclerView.adapter=BirdAdapter(birdDataList.toList())
        }



    }//end on create


    private fun readJsonFileFromAssets(fileName:String):String?{
        val assetManager:AssetManager=assets
        val json:String
        try{

            val inputStream=assetManager.open(fileName)
            val size=inputStream.available()
            val buffer=ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()
            json=String(buffer,Charsets.UTF_8)

        }catch(e:IOException){
            e.printStackTrace()
            return null
        }
        return json
    }


}//end class
