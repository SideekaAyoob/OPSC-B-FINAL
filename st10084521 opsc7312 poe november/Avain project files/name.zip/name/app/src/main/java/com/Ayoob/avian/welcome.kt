package com.Ayoob.avian

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import java.util.Timer
import java.util.TimerTask

class welcome : AppCompatActivity() {

//Variables
    private val delay:Long=5000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)

        val timer=Timer()

        val timerTask=object:TimerTask(){
            override fun run(){
                finish()
                val nextPage=Intent(this@welcome,Login::class.java)
                startActivity(nextPage)
            }
        }//end timer task

        timer.schedule(timerTask, delay)//start timer

    }//end on create

}//end class
