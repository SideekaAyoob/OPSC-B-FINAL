package com.Ayoob.avian

class PointsDataClass {
        var dataPoints:Int?=0
        var entryName:String? = null
        constructor(dataPoints:Int?,entryName:String? ){
            this.dataPoints=dataPoints
            this.entryName = entryName
        }
        constructor()

}// end class