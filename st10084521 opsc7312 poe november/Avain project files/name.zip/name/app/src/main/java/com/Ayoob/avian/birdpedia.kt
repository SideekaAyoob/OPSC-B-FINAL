package com.Ayoob.avian

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
//import com.example.name.R

class birdpedia : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_birdpedia)

        val webView=findViewById<WebView>(R.id.webView)

        webView.webViewClient=WebViewClient()

        val url="https://ebird.org/region/saf"
        webView.loadUrl(url)


    }// end on create
}// end class