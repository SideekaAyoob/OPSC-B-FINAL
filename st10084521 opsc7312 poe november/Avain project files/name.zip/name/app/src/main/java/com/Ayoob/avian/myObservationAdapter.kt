package com.Ayoob.avian

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide


class myObservationAdapter
(private val context: Context, private var dataList: List<myObservationsDataClass>) : RecyclerView.Adapter<MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.my_observation_recycleview, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        Glide.with(context).load(dataList[position].dataImage)
            .into(holder.recImage)
        holder.recBirdTitle.text = dataList[position].dataBirdName
        holder.recDesc.text = dataList[position].dataObservationDesc
        holder.recdate.text = dataList[position].dataObservationDate
        holder.reclocation.text = dataList[position].dataObservationLocation

        holder.recCard.setOnClickListener {
            val intent = Intent(context, myObservationDetails::class.java)
            intent.putExtra("Image", dataList[holder.adapterPosition].dataImage)
            intent.putExtra("Description", dataList[holder.adapterPosition].dataObservationDesc)
            intent.putExtra("Title", dataList[holder.adapterPosition].dataBirdName)
            intent.putExtra("date", dataList[holder.adapterPosition].dataObservationDate)
             intent.putExtra("location", dataList[holder.adapterPosition].dataObservationLocation)
     context.startActivity(intent)
        }

    }// end on binding

    override fun getItemCount(): Int {
        return dataList.size
    }

    fun searchDataList(searchList: List<myObservationsDataClass>) {
        dataList = searchList
        notifyDataSetChanged()
    }
}

class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
     var recImage: ImageView
    var recBirdTitle: TextView
    var recDesc: TextView
    var recdate: TextView
    var reclocation: TextView
    var recCard: CardView
    init {
          recImage = itemView.findViewById(R.id.recImage)
        recBirdTitle = itemView.findViewById(R.id.recBirdName)
        recDesc = itemView.findViewById(R.id.recdesc)
        recdate= itemView.findViewById(R.id.recDate)
        reclocation = itemView.findViewById(R.id.recLocation)
        recCard = itemView.findViewById(R.id.recCard)
    }
}// end class
