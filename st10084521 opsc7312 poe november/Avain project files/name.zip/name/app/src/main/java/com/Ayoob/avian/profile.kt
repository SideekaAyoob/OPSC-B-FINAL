package com.Ayoob.avian

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class profile : AppCompatActivity() {
    //variables

    //addded
    var eventListener: ValueEventListener? = null
    private lateinit var dataList: ArrayList<myObservationsDataClass>
    private lateinit var adapter: myObservationAdapter
    private lateinit var database: DatabaseReference
    //design components
    private lateinit var recycleV:RecyclerView
    private lateinit var addButton:FloatingActionButton

    private lateinit var mAuth: FirebaseAuth
    var points= 0
    private lateinit var pointstxt:TextView



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        //typecasting
        recycleV=findViewById(R.id.recyclerView)
        addButton=findViewById(R.id.fabAdd)
        pointstxt=findViewById(R.id.pointsTextView)
        mAuth=FirebaseAuth.getInstance()

        //added
        val gridLayoutManager = GridLayoutManager(this@profile, 1)

        recycleV.layoutManager= gridLayoutManager


        val builder = AlertDialog.Builder(this@profile)
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()

        dataList = ArrayList()
        adapter= myObservationAdapter(this@profile,dataList)

        recycleV.adapter = adapter

        // for final
        val userid = mAuth.currentUser!!.uid
        val Route ="$userid/MyObservations" //


        database =
            FirebaseDatabase.getInstance().getReference(Route)
        dialog.show()

        eventListener = database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                dataList.clear()
                for (itemSnapshot in snapshot.children) {
                    val dataClass = itemSnapshot.getValue(myObservationsDataClass::class.java)
                    if (dataClass != null) {
                        dataList.add(dataClass)
                        points += 50
                    }
                }
                adapter.notifyDataSetChanged()
                pointstxt.text= "Points :$points"
                updatePoints()
                dialog.dismiss()
            }// end onDataChange

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@profile, "no entries", Toast.LENGTH_LONG).show()
            }// end onCancelled

        })// end  eventListener


        addButton.setOnClickListener{
            val intent = Intent(this@profile, create_My_Observation::class.java)
            startActivity(intent)
        }


    }//end on create


    private fun updatePoints( )
    {

        val uid=mAuth.currentUser?.uid
        val pointsRoute="$uid/Points"

        val databaseReference=FirebaseDatabase.getInstance().getReference(pointsRoute).child("MyObservationPoints")

//Create a Map with the update data
        val updatedData = mapOf(
            "dataPoints" to points,
            "entryName" to "MyObservationPoints"
        )

//Update the data in the database
        databaseReference.updateChildren(updatedData)
            .addOnCompleteListener{task->
                if(task.isSuccessful){
                    Toast.makeText(this@profile,"points updated successfully",Toast.LENGTH_SHORT).show()
                    // finish()
                }else{
                    Toast.makeText(this@profile,"Update failed",Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener{e->
                Toast.makeText(this@profile,e.message.toString(),Toast.LENGTH_SHORT).show()
            }
        // }

    }//endupdate


}// end class