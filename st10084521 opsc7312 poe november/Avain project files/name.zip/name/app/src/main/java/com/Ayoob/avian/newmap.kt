package com.Ayoob.avian

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.content.pm.PackageManager
import android.graphics.Rect
import android.location.GpsStatus
import android.location.Location
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
//import android.telephony.SmsManager
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import android.widget.ToggleButton
import androidx.core.app.ActivityCompat
import androidx.core.content.res.ResourcesCompat

//import com.sideeka.avian.databinding.ActivityNewmapBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.Ayoob.avian.databinding.ActivityNewmapBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.api.IMapController
import org.osmdroid.bonuspack.routing.OSRMRoadManager
import org.osmdroid.bonuspack.routing.Road
import org.osmdroid.bonuspack.routing.RoadManager
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.IMyLocationConsumer
import org.osmdroid.views.overlay.mylocation.IMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay

class newmap : AppCompatActivity(),IMyLocationProvider,MapListener,GpsStatus.Listener  {

    private lateinit var mMap: MapView
    private lateinit var controller: IMapController
    private lateinit var mMyLocationOverlay: MyLocationNewOverlay
    private lateinit var mapController: IMapController
    private val LOCATION_REQUEST_CODE = 100

    private val noteMap = HashMap<GeoPoint,String>()

    //Declare global variables for latitude and longitude
    private var latitude :Double=0.0
    private var longitude :Double =0.0

    val hotspotLocations= listOf(
        Pair("Hluhluwe iMfolozi Park",GeoPoint(-28.219831,31.951865)),
        Pair("Umgeni River Bird Park",GeoPoint(-29.808167,31.017467)),
        Pair("Durban Japanese Gardens",GeoPoint(-29.7999,31.03758))
    )

    private val hotspotMarkers=
        mutableListOf<Marker>() //Initialize an empty list for hotspot markers

   // private var usersDistance :Double =  0.0
    val hotspotDistance = ArrayList<Double>()
    val hotspotMessage = ArrayList<String>()

    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding=ActivityNewmapBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setContentView(R.layout.activity_newmap)

        mAuth= FirebaseAuth.getInstance()
        createUserSettingsProfiles()
        //val sendSmsButton=findViewById<Button>(R.id.sendLocationButton)

        //Inside you onCreate()Method
        //val phoneNumberEditText=findViewById<EditText>(R.id.phoneNumberEditText)

        Configuration.getInstance().load(
            applicationContext,
            getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE)
        )
        mMap = findViewById(R.id.mapView)
        mMap.setTileSource(TileSourceFactory.MAPNIK)
        mMap.mapCenter
        mMap.setMultiTouchControls(true)
        mMap.getLocalVisibleRect(Rect())

        mMyLocationOverlay = MyLocationNewOverlay(GpsMyLocationProvider(this), mMap)
        controller = mMap.controller

        mMyLocationOverlay.enableMyLocation()
        mMyLocationOverlay.enableFollowLocation()
        mMyLocationOverlay.isDrawAccuracyEnabled = true

        //set the initial zoom level
        controller.setZoom(6.0)

        mMap.overlays.add(mMyLocationOverlay)

        setupMap()     //this function adds the marker for the start point
        mMap.addMapListener(this)

        // Check and request  location permissions
        managePermissions()

        // Create a custom overlay for the animated marker
        val animatedMarkerOverlay = object : Overlay(this) {
            override fun onSingleTapConfirmed(event: MotionEvent, mapView: MapView?): Boolean {
                // Calculate the longitude and latitude from the geopoint
                val geoPoint = mMyLocationOverlay.myLocation
                latitude = geoPoint.latitude
                longitude = geoPoint.longitude

                //create a custom dialog or info window to display the latitude and longitude

                val dialog = Dialog(this@newmap)
                dialog.setContentView(R.layout.custom)

                val latitudeTextView = dialog.findViewById<TextView>(R.id.LatitudeTextView)
                val longitudeTextView = dialog.findViewById<TextView>(R.id.longitudeTextView)

                latitudeTextView.text = "Latitude:$latitude"
                longitudeTextView.text = "Longitude:$longitude"

                dialog.show()
                return true
            }
        }

        mMap.overlays.add(animatedMarkerOverlay)
        displayBirdObservationsOnMap()
        val viewHotspotsButton=findViewById<Button>(R.id.viewHotspotsButton)

        viewHotspotsButton.setOnClickListener{
            //call a function to add hotspot markers when the button is clicked
            addHotspotMarkers()
        }

        val  showRoutesButton = findViewById<Button>(R.id.buttonroutes)
        showRoutesButton.setOnClickListener{
            calculateAndDisplay()
        }

    }// wnd on create

    private fun setupMap() {
        Configuration.getInstance().load(this, PreferenceManager.getDefaultSharedPreferences(this))
        mapController = mMap.controller
        mMap.setMultiTouchControls(true)

        // Init the start point
        val startPoint = GeoPoint(-29.8587, 31.0218)
        mapController.setCenter(startPoint)
        mapController.setZoom(6.0)

        // Create a marker
        val iconLocationMarker = Marker(mMap)
        iconLocationMarker.position = startPoint // Where you want the marker
        iconLocationMarker.icon = ResourcesCompat.getDrawable(resources, R.drawable.baseline_location_on_24, null)

        //add a click listener to the ic-location marker
        iconLocationMarker.setOnMarkerClickListener { marker, mapView ->
            val latitude = marker.position.latitude
            val longitude = marker.position.longitude
            val dialog = Dialog(this@newmap)
            dialog.setContentView(R.layout.custom)

            val longitudeTextView = dialog.findViewById<TextView>(R.id.longitudeTextView)
            val latitudeTextView = dialog.findViewById<TextView>(R.id.LatitudeTextView)

            latitudeTextView.text = "Latitude: $latitude"
            longitudeTextView.text = "Longitude:$longitude"
            dialog.show()
            true //return true to indicate that the event is consumed
        }
        mMap.overlays.add(iconLocationMarker)
    }// end set up  map

    private fun addHotspotMarkers()
    {
        //clear any existing hotspot markers from the map
        mMap.overlays.removeAll(hotspotMarkers)
   for((name,location) in hotspotLocations)
                            {
                                val marker =Marker(mMap)
                                marker.position=location
                                // marker.title=name
                                // hotspotMarkers.add(marker) //add the marker to the list
                                marker.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM)
                                marker.icon = ResourcesCompat.getDrawable(resources,R.drawable.baseline_share_location_24,null)

                                marker.setOnMarkerClickListener { marker, mapView ->
                                    val dialog = Dialog(this@newmap)
                                    dialog.setContentView(R.layout.custom_marker_dialog)
                                    val noteEdittext = dialog.findViewById<EditText>(R.id.noteEditText)
                                    val saveNoteButton = dialog.findViewById<Button>(R.id.saveNoteButton)
                                    val displayNoteTextView = dialog.findViewById<TextView>(R.id.displayNoteTv)

                                    val LocationNameTextview = dialog.findViewById<TextView>(R.id.locationNameTextView)
                                    LocationNameTextview.text = name

                                    val savedNote = loadNote(marker.position)
                                    displayNoteTextView.text = savedNote

                                    saveNoteButton.setOnClickListener{
                                        val note = noteEdittext.text.toString()
                                        //saveNote(marker.position,note)
                                        saveBirdObservation(marker.position,note)
                                        displayNoteTextView.text = note
                                    }// end save note button click

                                    dialog.show()
                                    true
                                }//end marker

                                hotspotMarkers.add(marker)
                            }// end for loop

                            mMap.overlays.addAll(hotspotMarkers)
                            mMap.invalidate() //refresh the map to display the new markers

    }// end addHotspotMarker

 /*   private fun saveNote(location:GeoPoint, note: String){
        noteMap[location] = note
    }// end save note
  */
    ///////////////////////////////////////////////////////////////////////////////////////////////////
 private fun saveBirdObservation(location: GeoPoint, note: String) {
     // Create a reference to the "bird_observations" node
     val birdObservationsReference = FirebaseDatabase.getInstance().reference.child("bird_observations")

     // Create a unique key for the new observation
     val newObservationKey = birdObservationsReference.push().key

     // Create a data object for the observation
     val observationData = HashMap<String, Any>()
     observationData["locationLatitude"] = location.latitude
     observationData["locationLongitude"] = location.longitude
     observationData["noteText"] = note

     // Save the observation to the database under the unique key
     newObservationKey?.let { birdObservationsReference.child(it).setValue(observationData) }
         ?.addOnSuccessListener {
             Toast.makeText(this, "Bird observation saved to the database", Toast.LENGTH_SHORT).show()

             // After saving, immediately display the observation on the map
             val observationMarker = Marker(mMap)
             observationMarker.position = location
             observationMarker.title = note
             mMap.overlays.add(observationMarker)
             mMap.invalidate()
         }
         ?.addOnFailureListener {
             Toast.makeText(this, "Failed to save bird observation: ${it.message}", Toast.LENGTH_SHORT).show()
         }
    }


    private fun displayBirdObservationsOnMap() {
        val birdObservationsReference =FirebaseDatabase.getInstance().reference.child("bird_observations")

        birdObservationsReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                try {
                    for (observationSnapshot in dataSnapshot.children) {
                        val locationLatitude = observationSnapshot.child("locationLatitude").value as Double
                        val locationLongitude = observationSnapshot.child("locationLongitude").value as Double
                        val noteText = observationSnapshot.child("noteText").value as String

                        // Create a map marker for the observation and add it to the map
                        val observationMarker = Marker(mMap)
                        val observationLocation = GeoPoint(locationLatitude, locationLongitude)
                        observationMarker.position = observationLocation
                        observationMarker.title = noteText

                        // Add the marker to the map overlays
                        mMap.overlays.add(observationMarker)
                    }
                } catch (e: Exception) {
                    Log.e("Firebase", "Error displaying bird observations: ${e.message}")
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle errors
                Log.e("Firebase", "Error retrieving bird observations: ${databaseError.message}")
            }
        })
    }


/////////////////////////////////////////////////////////////////////////////////////////////////////


    private fun loadNote(location: GeoPoint):String{
        return  noteMap[location] ?:""
    }// end load note

    private fun isLocationPermissionGranted(): Boolean {
        val fineLocation =
            ActivityCompat.checkSelfPermission(this@newmap,
                android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val courseLocation =
            ActivityCompat.checkSelfPermission(this@newmap,
                android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

        return fineLocation && courseLocation
    }// end is location Permission granted

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == LOCATION_REQUEST_CODE) {
            if (grantResults.isNotEmpty()) {

                for (result in grantResults) {
                    if (result == PackageManager.PERMISSION_GRANTED) {
                        //handle location permission granted
                        //you can re initialize the map here if needed

                    }else
                    {
                       // Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show()
                    }// end if
                }// end for loop

            }//end inner if
        }// end if
    }// end onRequestPermissionsResult(

    private fun managePermissions() {
        val requestPermissions = mutableListOf<String>()

        //location permissions
        if (!isLocationPermissionGranted()) {
            // Permissions are not granted, add them to the request
            requestPermissions.add(android.Manifest.permission.ACCESS_FINE_LOCATION)
            requestPermissions.add(android.Manifest.permission.ACCESS_COARSE_LOCATION)
        }// end if 1

        if (!isSmsPermissionGranted())
        {
            requestPermissions.add(android.Manifest.permission.SEND_SMS)
        }// end if 2

        if (requestPermissions.isNotEmpty())
        {
            ActivityCompat.requestPermissions(
                this@newmap,
                requestPermissions.toTypedArray(),
                LOCATION_REQUEST_CODE)
        }// end if 3

    }// end managePermissions()

    private fun isSmsPermissionGranted():Boolean{
        return ActivityCompat.checkSelfPermission(
            this@newmap,
            android.Manifest.permission.SEND_SMS
        )==PackageManager.PERMISSION_GRANTED
    }

    override fun startLocationProvider(myLocationConsumer: IMyLocationConsumer?): Boolean {
        return true
    }

    override fun stopLocationProvider() {}

    override fun getLastKnownLocation(): Location {
        return Location("last_known_location")
    }

    override fun destroy() {}

    override fun onScroll(event: ScrollEvent?): Boolean {
        return true
    }

    override fun onZoom(event: ZoomEvent?): Boolean {
        return false
    }

    override fun onGpsStatusChanged(p0: Int) {}

    // here change for the users distance
    @SuppressLint("SuspiciousIndentation")
    private fun calculateAndDisplay() {
        val startPoint = mMyLocationOverlay.myLocation
        var measurementToggle: Boolean = false

        updateSettings()

        // Calculate the distance in meters (or a similar unit) from the 'road' object
        val toggleButton = findViewById<ToggleButton>(R.id.toggleSystem)
         measurementToggle= toggleButton.isChecked



        if(startPoint == null){
            Toast.makeText(this@newmap, "Location loading error", Toast.LENGTH_SHORT).show()
            return
        }// end if

        for((startLocationName,endPoint) in hotspotLocations){
            GlobalScope.launch(Dispatchers.IO){
                val roadManager = OSRMRoadManager(this@newmap,"OBP_Tuto/1.0")
                var road :Road?  = null
                var retryCount = 0

                while (road == null && retryCount < 3){
                    road = try{
                        roadManager.getRoad(arrayListOf(startPoint,endPoint))
                    }catch (e:java.lang.Exception){
                        null
                    }// end try
                    retryCount++
                }// end while

                withContext(Dispatchers.Main){
                    if(road != null && road.mStatus == Road.STATUS_OK){
                        val  roadOverlay = RoadManager.buildRoadOverlay(road)
                        mMap.overlays.add(roadOverlay)
                        /////////////////////////////////////////////////////////

                        //add toggle
                        var distance= road.mLength//val distanceKilometers= road.mLength
                        var distanceText = ""

                        // Convert the distance based on the selected road type
                        if (measurementToggle) {
                            // Metric system (kilometers)
                           //val distanceKilometers = distanceKilometers

                            distanceText = String.format("%.2f km", distance)

                        } else {
                            // Imperial system (miles)
                           // val distanceMiles = distanceKilometers / 1609.34
                            distance = kiloMetersToMiles(distance) //val distanceMiles = kiloMetersToMiles(distanceKilometers)
                            distanceText = String.format("%.2f miles", distance)

                          //  usersDistance = kiloMetersToMiles(usersDistance)

                        }// end if  is checked

                        // Create the route details string
                        val routeDetails = "Start Location: Your current location\nEnd Location: $startLocationName\nDistance: $distanceText"


                            showRouteDetailsDialog(routeDetails)


                        mMap.invalidate()
                    }else{
                        Toast.makeText(this@newmap, "Error when loading road - status = ${road?.mStatus?:"unknown"}", Toast.LENGTH_SHORT).show()
                    }// end if
                }// end with context
                val pies= "pies"
            }// end global scope
            val pies= "pies"
        }// end for loop
        val pies= "pies"

    }// end method

    fun kiloMetersToMiles(kilometers: Double): Double {
        return kilometers * 0.621371
    }

    private fun showRouteDetailsDialog(routeDetails: String) {
        runOnUiThread{
            val alertDialog = AlertDialog.Builder(this@newmap)
            alertDialog.setTitle("route details")
            alertDialog.setMessage(routeDetails)
            alertDialog.setPositiveButton("ok"){dialog, _ ->
                dialog.dismiss()
            }
            alertDialog.create().show()
        }
    }// end show Route Details Dialog

    private fun updateSettings()
    {
        var measurementToggle: Boolean = false
        val toggleButton = findViewById<ToggleButton>(R.id.toggleSystem)
        measurementToggle= toggleButton.isChecked
        var measumentName= ""

        if (measurementToggle) {
            measumentName ="KiloMeters"
        } else {
            measumentName ="Miles"
        }// end if  is checked

        val uid=mAuth.currentUser?.uid
        val pointsRoute="$uid/Settings"

        val databaseReference= FirebaseDatabase.getInstance().getReference(pointsRoute).child("MySettings")

//Create a Map with the update data
        val updatedData = mapOf(
            "measurment" to measumentName.toString(),
            "settingname" to "MySettings"
        )

//Update the data in the database
        databaseReference.updateChildren(updatedData)
            .addOnCompleteListener{task->
                if(task.isSuccessful){
                    Toast.makeText(this@newmap,"Settings updated successfully",Toast.LENGTH_SHORT).show()
                    // finish()
                }else{
                   // Toast.makeText(this@newmap,"Update failed",Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener{e->
                //Toast.makeText(this@newmap,e.message.toString(),Toast.LENGTH_SHORT).show()
            }
        // }



    }
    private fun createUserSettingsProfiles() {
        var measurementToggle: Boolean = false
        val toggleButton = findViewById<ToggleButton>(R.id.toggleSystem)
        measurementToggle= toggleButton.isChecked
        var measumentName= ""


        if (measurementToggle) {
            measumentName ="KiloMeters"
        } else {
            measumentName ="Miles"
        }// end if  is checked


        val uid=mAuth.currentUser?.uid
        val uidpoints = "$uid/Settings"
        val diaryDataClass = settingDataClass(measumentName, "MySettings")//
        FirebaseDatabase.getInstance().getReference(uidpoints).child("MySettings")
            .setValue(diaryDataClass).addOnCompleteListener { task ->
                if (task.isSuccessful) {

                }
            }.addOnFailureListener { e ->

            }// end firebase else


    }// end

}// end class


